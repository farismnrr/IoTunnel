-- Insert sample products
INSERT INTO products (id, product_name, description, price, duration) VALUES
('PROD001', 'Basic Plan', 'Access to basic features for 1 month', 99, '1 month'),
('PROD002', 'Standard Plan', 'Access to standard features for 3 months', 249, '3 months');